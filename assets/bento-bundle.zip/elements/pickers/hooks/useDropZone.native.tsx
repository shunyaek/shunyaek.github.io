export function useDropZone(options: any) {
  //fallback to make kitchensink work with bento
  return {}
}
