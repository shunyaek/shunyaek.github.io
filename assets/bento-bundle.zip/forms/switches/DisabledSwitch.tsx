/**
 *
 *  THIS COMPONENT IS REMOVED FROM BENTO
 *
 *
 */
// import { useEvent } from '@tamagui/core'
// import { Switch } from '@tamagui/switch'
// import { useState } from 'react'
// import { View } from 'tamagui'

// /** ------ EXAMPLE ------ */
// export function DisabledSwitch() {
//   const [disabled, setDisabled] = useState(true)
//   const [checked, setChecked] = useState(false)
//   const toggleChecked = useEvent(() => {
//     if (!disabled) setChecked(!checked)
//   })
//   return (
//     <View flexDirection="column">
//       <Switch
//         size="$2"
//         pointerEvents={checked ? 'auto' : 'none'}
//         checked={checked}
//         disabled={disabled}
//         onCheckedChange={toggleChecked}
//       >
//         <Switch.Thumb animation="bouncy" />
//       </Switch>
//     </View>
//   )
// }

// DisabledSwitch.fileName = 'DisabledSwitch'
